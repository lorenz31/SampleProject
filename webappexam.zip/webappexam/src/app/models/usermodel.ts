export class Usermodel {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
}
