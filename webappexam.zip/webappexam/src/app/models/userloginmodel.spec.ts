import { Userloginmodel } from './userloginmodel';

describe('Userloginmodel', () => {
  it('should create an instance', () => {
    expect(new Userloginmodel()).toBeTruthy();
  });
});
