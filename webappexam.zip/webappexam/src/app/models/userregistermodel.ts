export class Userregistermodel {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
}
