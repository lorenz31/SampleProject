import { Userregistermodel } from './userregistermodel';

describe('Userregistermodel', () => {
  it('should create an instance', () => {
    expect(new Userregistermodel()).toBeTruthy();
  });
});
