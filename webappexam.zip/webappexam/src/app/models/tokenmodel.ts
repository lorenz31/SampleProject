export class Tokenmodel {
    accessToken: string;
    userId: string;
    name: string;
}
