import { Responsemodel } from './responsemodel';

describe('Responsemodel', () => {
  it('should create an instance', () => {
    expect(new Responsemodel()).toBeTruthy();
  });
});
