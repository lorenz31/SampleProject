export class Userloginmodel {
    email: string;
    password: string;
}
