import { Tokenmodel } from './tokenmodel';

describe('Tokenmodel', () => {
  it('should create an instance', () => {
    expect(new Tokenmodel()).toBeTruthy();
  });
});
