export class Responsemodel {
    status: boolean;
    message: string;
}
