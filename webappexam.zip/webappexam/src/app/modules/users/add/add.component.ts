import { Component, OnInit } from '@angular/core';

import { Usermodel } from 'src/app/models/usermodel';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {

  user = new Usermodel();

  constructor() { }

  ngOnInit() {
  }

}
