import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/components/common/messageservice';

import { UserService } from 'src/app/services/user.service';
import { Usermodel } from 'src/app/models/usermodel';
import { Responsemodel } from 'src/app/models/responsemodel';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  displayAddDlg: boolean;
  displayEdtDlg: boolean;

  cols: any[];
  users: Usermodel[];
  selectedUser = new Usermodel();
  user = new Usermodel();
  response: Responsemodel;
  op: string;

  constructor(
    private userSvc: UserService,
    private msgSvc: MessageService,
    private router: Router
  ) { }

  ngOnInit() {
    this.displayAddDlg = false;
    this.displayEdtDlg = false;
    this.cols = [
      { field: 'firstName', header: 'First Name' },
      { field: 'lastName', header: 'Last Name' },
      { field: 'email', header: 'Email' },
      { field: 'options', header: 'Option(s)' }
    ];

    this.loadUsers();
  }

  addDlg() {
    this.displayAddDlg = true;
  }

  addUser() {
    this.userSvc
      .registerUser(this.user)
      .then(resp => {
        if (resp.status) {
          this.msgSvc.add({key: 'addsuc', severity: 'success', summary: 'New user added', detail: resp.message});
          this.clearFields();
          this.displayAddDlg = false;
          this.loadUsers();
        }
      });
  }

  editDlg(user: Usermodel) {
    this.selectedUser = user;
    this.displayEdtDlg = true;
  }

  updateInfo() {
    this.userSvc
      .updateUser(this.selectedUser)
      .then(resp => {
        if (resp.status) {
          this.msgSvc.add({key: 'edtsuc', severity: 'success', summary: 'Registration Successful!', detail: resp.message});
          this.clearFields();
          this.displayEdtDlg = false;
          this.loadUsers();
        }
      });
  }

  delete(id: string) {
    this.userSvc
      .deleteUser(id)
      .then(resp => {
        if (resp.status) {
          this.loadUsers();
        }
      });
  }

  loadUsers() {
    this.userSvc
      .getUsers()
      .then(users => this.users = users);
  }

  clearFields() {
    this.selectedUser.id = '';
    this.selectedUser.firstName = '';
    this.selectedUser.lastName = '';
    this.selectedUser.email = '';
    this.selectedUser.password = '';

    this.user.id = '';
    this.user.firstName = '';
    this.user.lastName = '';
    this.user.email = '';
    this.user.password = '';
  }

  logout() {
    this.userSvc.logout();
    this.router.navigateByUrl('home');
  }

}
