import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MenubarModule } from 'primeng/menubar';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';

@NgModule({
  imports: [
    CommonModule,
    MenubarModule,
    InputTextModule,
    ButtonModule,
    ToastModule,
    TableModule,
    DialogModule
  ],
  exports: [
    MenubarModule,
    InputTextModule,
    ButtonModule,
    ToastModule,
    TableModule,
    DialogModule
  ]
})
export class PrimengModule { }
