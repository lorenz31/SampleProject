import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

import { Apiurlhelper } from '../helpers/apiurlhelper';
import { Userloginmodel } from '../models/userloginmodel';
import { Tokenmodel } from '../models/tokenmodel';
import { Responsemodel } from '../models/responsemodel';
import { Userregistermodel } from '../models/userregistermodel';
import { Usermodel } from '../models/usermodel';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private httpClient: HttpClient,
    private urlHelper: Apiurlhelper
  ) { }

  public registerUser(user: Userregistermodel) {
    let headers = new HttpHeaders({
      'Content-type': 'application/json'
    });

    return this.httpClient
      .post(
        this.urlHelper.getApiUrl() + this.urlHelper.registrationApiUrl,
        JSON.stringify(user),
        { headers: headers }
      )
      .toPromise()
      .then(res => <Responsemodel> res)
      .then(data => data)
      .catch(err => err);
  }

  public authenticateUser(user: Userloginmodel) {
    let headers = new HttpHeaders({
      'Content-type': 'application/json'
    });

    return this.httpClient
      .post(
        this.urlHelper.getApiUrl() + this.urlHelper.tokenApiUrl,
        JSON.stringify(user),
        { headers: headers }
      )
      .pipe(
        map((result: Tokenmodel) => {
          // login successful if there's a jwt token in the response
          if (result && result.accessToken) {
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('token', result.accessToken);
            localStorage.setItem('userid', result.userId);
          }
  
          return result;
        })
      );
  }

  public getUsers() {
    let headers = new HttpHeaders({
      'Accept': 'application/json',
      'Authorization': 'bearer ' + localStorage.getItem('token')
    });

    return this.httpClient
      .get(
        this.urlHelper.getApiUrl() + this.urlHelper.userApiUrl,
        { headers: headers }
      )
      .toPromise()
      .then(res => <Usermodel[]> res)
      .then(data => data)
      .catch(err => err);
  }

  public updateUser(user: Usermodel) {
    let headers = new HttpHeaders({
      'Content-type': 'application/json',
      'Authorization': 'bearer ' + localStorage.getItem('token')
    });

    return this.httpClient
      .put(
        this.urlHelper.getApiUrl() + this.urlHelper.userApiUrl,
        JSON.stringify(user),
        { headers: headers }
      )
      .toPromise()
      .then(res => <Responsemodel> res)
      .then(data => data)
      .catch(err => err);
  }

  public deleteUser(id: string) {
    let headers = new HttpHeaders({
      'Authorization': 'bearer ' + localStorage.getItem('token')
    });

    return this.httpClient
      .delete(
        this.urlHelper.getApiUrl() + this.urlHelper.userApiUrl + '/' + id,
        { headers: headers }
      )
      .toPromise()
      .then(res => <Responsemodel> res)
      .then(data => data)
      .catch(err => err);
  }

  logout() {
    localStorage.clear();
  }

}
