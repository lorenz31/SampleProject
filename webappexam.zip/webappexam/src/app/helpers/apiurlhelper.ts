export class Apiurlhelper {
    getApiUrl() {
        return 'http://localhost:51603/';
        // return "http://devapi.somee.com/";
    }

    clientApp() {
        return 'webapp';
    }

    tokenApiUrl: string = 'api/user/login';
    registrationApiUrl: string = 'api/user/register';
    userApiUrl: string = 'api/user';
}