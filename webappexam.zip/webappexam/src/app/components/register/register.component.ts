import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/components/common/messageservice';
import { Router } from '@angular/router';

import { UserService } from 'src/app/services/user.service';

import { Userregistermodel } from 'src/app/models/userregistermodel';
import { Responsemodel } from 'src/app/models/responsemodel';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  user = new Userregistermodel();

  constructor(
    private userSvc: UserService,
    private msgSvc: MessageService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  register() {
    this.userSvc
      .registerUser(this.user)
      .then(res => {
        this.msgSvc.add({key: 'suc', severity: 'success', summary: 'Registration Successful!', detail: res.message});
        this.clearFields();
        this.router.navigateByUrl('home/login');
      })
      .catch((error: Responsemodel) => {
        this.msgSvc.add({key: 'err', severity: 'error', detail: error.message});
        console.log(error);
      });
      // .subscribe(
      //   response => {
      //     this.msgSvc.add({key: 'suc', severity: 'success', summary: 'Registration Successful!', detail: response.message});
      //     this.clearFields();
      //   },
      //   (error: Responsemodel) => {
      //     this.msgSvc.add({key: 'err', severity: 'error', detail: error.message});
      //     console.log(error);
      //   }
      // );
  }

  clearFields() {
    this.user.firstName = '';
    this.user.lastName = '';
    this.user.email = '';
    this.user.password = '';
  }

}
