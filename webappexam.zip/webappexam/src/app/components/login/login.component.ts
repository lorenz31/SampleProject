import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { UserService } from 'src/app/services/user.service';
import { MessageService } from 'primeng/components/common/messageservice';

import { Userloginmodel } from 'src/app/models/userloginmodel';
import { Responsemodel } from 'src/app/models/responsemodel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  user = new Userloginmodel();

  constructor(
    private router: Router,
    private userSvc: UserService,
    private msgSvc: MessageService
  ) { }

  ngOnInit() {
  }

  login() {
    this.userSvc
      .authenticateUser(this.user)
      .subscribe(
        response => {
          this.msgSvc.add({key: 'suc', severity: 'success', summary: 'Login Successful!', detail: 'Welcome ' + response.name});
          this.router.navigateByUrl('users');
        },
        (error: Responsemodel) => {
          this.msgSvc.add({key: 'err', severity: 'error', detail: error.message});
        }
      );
  }

}
