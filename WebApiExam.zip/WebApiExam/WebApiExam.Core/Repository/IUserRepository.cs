﻿using WebApiExam.Core.BusinessModels.Contract;
using WebApiExam.Core.BusinessModels;
using WebApiExam.Core.Models;

using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace WebApiExam.Core.Repository
{
    public interface IUserRepository
    {
        Task<IResponseModel> RegisterUserAsync(UserRegisterModel model);
        Task<User> VerifyUserAsync(UserLoginModel model);
        Task<IResponseModel> AddUserAsync(UserModel model);
        Task<List<User>> GetUsersAsync();
        Task<IResponseModel> UpdateUserAsync(UserModel model);
        Task<IResponseModel> DeleteUserAsync(Guid userid);
    }
}
