﻿using System.Threading.Tasks;

namespace WebApiExam.Core.Services
{
    public interface IEmailService
    {
        void SendEmail(string recipient, string email);
    }
}
