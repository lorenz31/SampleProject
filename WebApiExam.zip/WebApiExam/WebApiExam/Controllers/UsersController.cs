﻿using WebApiExam.Core.Services;
using WebApiExam.Core.BusinessModels;
using WebApiExam.Core.BusinessModels.Contract;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;

namespace WebApiExam.Controllers
{
    [Authorize]
    [EnableCors("AllowSpecificOrigin")]
    [Produces("application/json")]
    [Route("api/User")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private IAccountService _accountService;
        private IResponseModel _response;

        public UsersController(
            IAccountService accountService,
            IResponseModel response)
        {
            _accountService = accountService;
            _response = response;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Create([FromBody] UserRegisterModel obj)
        {
            if (!ModelState.IsValid) return NoContent();

            var isRegistered = await _accountService.RegisterUserAsync(obj);

            _response.Status = isRegistered.Status;
            _response.Message = isRegistered.Message;

            if (_response.Status)
                return Ok(_response);
            else
                return BadRequest(_response);
        }

        [HttpPost]
        [Route("")]
        public async Task<IActionResult> AddUserAsync([FromBody] UserModel obj)
        {
            if (!ModelState.IsValid) return NoContent();

            var isRegistered = await _accountService.AddUserAsync(obj);

            _response.Status = isRegistered.Status;
            _response.Message = isRegistered.Message;

            if (_response.Status)
                return Ok(_response);
            else
                return BadRequest(_response);
        }

        [HttpGet]
        [Route("")]
        public async Task<IActionResult> GetUsersAsync()
        {
            return Ok(await _accountService.GetUsersAsync());
        }

        [HttpPut]
        [Route("")]
        public async Task<IActionResult> PutUserAsync([FromBody] UserModel obj)
        {
            if (!ModelState.IsValid) return NoContent();

            var isUpdated = await _accountService.UpdateUserAsync(obj);

            _response.Status = isUpdated.Status;
            _response.Message = isUpdated.Message;

            if (_response.Status)
                return Ok(_response);
            else
                return BadRequest(_response);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public async Task<IActionResult> DeleteUserAsync(Guid id)
        {
            var resp = await _accountService.DeleteUserAsync(id);

            _response.Status = resp.Status;
            _response.Message = resp.Message;

            if (_response.Status)
                return Ok(_response);
            else
                return BadRequest(_response);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> PostUserLoginAsync([FromBody] UserLoginModel obj)
        {
            if (!ModelState.IsValid) return NoContent();

            var userVerified = await _accountService.VerifyUserAsync(obj);

            if (userVerified == null) return NoContent();

            var token = _accountService.GenerateJwt(userVerified);

            return Ok(token);
        }
    }
}
