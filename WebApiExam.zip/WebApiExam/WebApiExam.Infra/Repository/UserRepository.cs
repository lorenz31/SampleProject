﻿using WebApiExam.Core.BusinessModels.Contract;
using WebApiExam.Core.BusinessModels;
using WebApiExam.Core.Repository;
using WebApiExam.Core.Models;
using WebApiExam.Infra.DataContext;

using System.Threading.Tasks;
using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApiExam.Infra.Repository
{
    public class UserRepository : IUserRepository
    {
        private DatabaseContext _db;
        private IResponseModel _response;

        public UserRepository(
            DatabaseContext db,
            IResponseModel response)
        {
            _db = db;
            _response = response;
        }

        public async Task<IResponseModel> RegisterUserAsync(UserRegisterModel model)
        {
            try
            {
                _db.Users.Add(new User
                {
                    Id = Guid.NewGuid(),
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password
                });

                await _db.SaveChangesAsync();

                _response.Status = true;
                _response.Message = "User registration successful.";

                return _response;
            }
            catch (Exception ex)
            {
                _response.Status = false;
                _response.Message = "User registration error.";

                return _response;
            }
        }

        public async Task<User> VerifyUserAsync(UserLoginModel model)
        {
            try
            {
                var userInfo = await _db.Users.Where(u => u.Email == model.Email && u.Password == model.Password).SingleOrDefaultAsync();

                if (userInfo != null) return userInfo;

                return null;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<IResponseModel> AddUserAsync(UserModel model)
        {
            try
            {
                var user = new User
                {
                    Id = Guid.NewGuid(),
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password
                };

                _db.Users.Add(user);
                await _db.SaveChangesAsync();

                _response.Status = true;
                _response.Message = "User added successfully.";
                
                return _response;
            }
            catch (Exception ex)
            {
                _response.Status = false;
                _response.Message = "Error adding user.";

                return _response;
            }
        }

        public async Task<List<User>> GetUsersAsync() => await _db.Users.ToListAsync();

        public async Task<IResponseModel> UpdateUserAsync(UserModel model)
        {
            try
            {
                var user = new User
                {
                    Id = model.Id,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    Email = model.Email,
                    Password = model.Password
                };

                _db.Users.Update(user);
                await _db.SaveChangesAsync();

                _response.Status = true;
                _response.Message = "Successfully updated user info.";

                return _response;
            }
            catch (Exception ex)
            {
                _response.Status = false;
                _response.Message = "Error updating user info.";

                return _response;
            }
        }

        public async Task<IResponseModel> DeleteUserAsync(Guid userid)
        {
            try
            {
                var user =  await _db.Users.Where(x => x.Id == userid).SingleOrDefaultAsync();

                if (user != null)
                {
                    _db.Users.Remove(user);
                    await _db.SaveChangesAsync();

                    _response.Status = true;
                    _response.Message = "User deleted successfully.";
                }
                else
                {
                    _response.Status = false;
                    _response.Message = "User deletion error.";
                }

                return _response;
            }
            catch (Exception ex)
            {
                _response.Status = false;
                _response.Message = "User deletion failed.";

                return _response;
            }
        }
    }
}
