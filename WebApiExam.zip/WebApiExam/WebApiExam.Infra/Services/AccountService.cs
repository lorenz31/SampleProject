﻿using WebApiExam.Core.Jwt;
using WebApiExam.Core.BusinessModels;
using WebApiExam.Core.BusinessModels.Implementation;
using WebApiExam.Core.BusinessModels.Contract;
using WebApiExam.Core.Services;
using WebApiExam.Core.Repository;
using WebApiExam.Core.Models;

using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using Microsoft.Extensions.Configuration;

namespace WebApiExam.Infra.Services
{
    public class AccountService : IAccountService
    {
        private IUserRepository _userRepo;
        private IConfiguration _config;
        private IEmailService _emailService;

        public AccountService(
            IUserRepository userRepo,
            IConfiguration config,
            IEmailService emailService)
        {
            _userRepo = userRepo;
            _config = config;
            _emailService = emailService;
        }

        public async Task<IResponseModel> RegisterUserAsync(UserRegisterModel model)
        {
            var response = await _userRepo.RegisterUserAsync(model);
            _emailService.SendEmail(string.Format($"{0} {1}", model.FirstName, model.FirstName), model.Email);

            return response;
        }

        public async Task<User> VerifyUserAsync(UserLoginModel model) => await _userRepo.VerifyUserAsync(model);

        public TokenModel GenerateJwt(User model)
        {
            var token = new JwtTokenBuilder(_config);

            return new TokenModel
            {
                AccessToken = token.GenerateToken(),
                UserId = model.Id,
                Name = model.Email
            };
        }

        public async Task<IResponseModel> AddUserAsync(UserModel model)
        {
            var response = await _userRepo.AddUserAsync(model);
            _emailService.SendEmail(string.Format($"{0} {1}", model.FirstName, model.FirstName), model.Email);

            return response;
        }

        public async Task<List<User>> GetUsersAsync() => await _userRepo.GetUsersAsync();

        public async Task<IResponseModel> UpdateUserAsync(UserModel model) => await _userRepo.UpdateUserAsync(model);

        public async Task<IResponseModel> DeleteUserAsync(Guid userid) => await _userRepo.DeleteUserAsync(userid);

        //public async Task<IResponseModel> SendEmailAsync()
        //{
        //}
    }
}