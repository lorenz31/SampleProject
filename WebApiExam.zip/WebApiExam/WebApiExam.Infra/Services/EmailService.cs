﻿using MailKit.Net.Smtp;
using Microsoft.Extensions.Configuration;
using MimeKit;
using System;

namespace WebApiExam.Infra.Services
{
    public class EmailService : Core.Services.IEmailService
    {
        private IConfiguration _config;

        public EmailService(IConfiguration config)
        {
            _config = config;
        }

        public void SendEmail(string recipient, string email)
        {
            MimeMessage message = new MimeMessage();

            MailboxAddress from = new MailboxAddress("Admin", _config["MailSettings:Sender"]);
            message.From.Add(from);

            MailboxAddress to = new MailboxAddress(recipient, email);
            message.To.Add(to);

            message.Subject = "Registration Successful";

            BodyBuilder bodyBuilder = new BodyBuilder();
            bodyBuilder.HtmlBody = $"<h1>Welcome, {recipient}!</h1>";

            message.Body = bodyBuilder.ToMessageBody();

            SmtpClient client = new SmtpClient();
            client.Connect(_config["MailSettings:SmtpServer"], Convert.ToInt16(_config["MailSettings:Port"]), true);
            client.Authenticate(_config["MailSettings:Username"], _config["MailSettings:Password"]);

            client.Send(message);
            client.Disconnect(true);
            client.Dispose();
        }
    }
}
